<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once "../config/connect.php";

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

$stmt = $conn->prepare(
    "SELECT password FROM users WHERE username = ?"
);

$stmt->bind_param("s", $username);
$stmt->execute();

$result = $stmt->get_result();

// if ($result->num_rows == 0) {

//     echo json_encode([
//         "success" => false,
//         "message" => "User tidak ditemukan",
//         "username" => $username
//     ]);

//     exit;
// }

if ($result->num_rows == 0) {

    echo json_encode([
        "success" => false,
        "message" => "User tidak ditemukan"
    ]);

    exit;
}

$user = $result->fetch_assoc();

if (
    password_verify(
        $password,
        $user['password']
    )
) {

    echo json_encode([
        "success" => true
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Password salah"
    ]);

}