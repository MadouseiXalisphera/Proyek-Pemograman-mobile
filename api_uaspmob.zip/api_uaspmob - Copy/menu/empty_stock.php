<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}
require_once "../config/connect.php";

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$id = (int)$data["id"];

$stmt = $conn->prepare(
    "UPDATE menu_items
     SET stock = 0
     WHERE id = ?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode([
    "success" => true
]);