<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/connect.php";

$sql = "
SELECT
    id,
    name,
    description,
    price,
    image_url,
    categories,
    is_top_pick,
    stock
FROM menu_items
";

$result = $conn->query($sql);

$menus = [];

while ($row = $result->fetch_assoc()) {

    $menus[] = [
    "id" => strval($row["id"]),
    "nama" => $row["name"],
    "deskripsi" => $row["description"],
    "harga" => (int)$row["price"],
    "kategori" => $row["categories"],
    "fotoPath" => $row["image_url"],
    "isTopPick" => (bool)$row["is_top_pick"],
    "stock" => (int)$row["stock"]
];
}

echo json_encode([
    "success" => true,
    "data" => $menus
]);