<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

// 1. KONFIGURASI CORS YANG BENAR UNTUK FLUTTER WEB & API JSON
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// 2. TANGKAP PREFLIGHT REQUEST (PENTING!)
// Jika ada request OPTIONS dari browser, langsung berikan status OK (200) lalu matikan proses
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once "../config/connect.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "message" => "Data kosong atau format JSON tidak sesuai"]);
    exit;
}

try {
    $conn->begin_transaction();

    // 3. PROSES SIMPAN GAMBAR BASE64
    $payment_proof_path = "";
    if (!empty($data['payment_proof_base64'])) {
        $base64_string = $data['payment_proof_base64'];
        $file_name = $data['payment_proof_name'] ?? 'proof.jpg';
        $ext = pathinfo($file_name, PATHINFO_EXTENSION);
        if(empty($ext)) $ext = 'jpg';
        
        $new_filename = uniqid('proof_') . '.' . $ext;
        
        if (!is_dir('../uploads')) {
            mkdir('../uploads', 0777, true);
        }
        
        $path = '../uploads/' . $new_filename;
        file_put_contents($path, base64_decode($base64_string));
        
        $payment_proof_path = 'uploads/' . $new_filename;
    }

    // Insert ke orders
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, table_name, phone, email, payment_method, total_price, payment_proof) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssds", $data['customer_name'], $data['table_name'], $data['phone'], $data['email'], $data['payment_method'], $data['total_price'], $payment_proof_path);
    $stmt->execute();
    
    $order_id = $conn->insert_id;

    // Insert items
    $stmtItem = $conn->prepare("INSERT INTO order_items (order_id, menu_name, quantity, price, status) VALUES (?, ?, ?, ?, ?)");
    foreach ($data['items'] as $item) {
        $stmtItem->bind_param("isids", $order_id, $item['menu_name'], $item['quantity'], $item['price'], $item['status']);
        $stmtItem->execute();
    }

    $conn->commit();
    echo json_encode(["success" => true, "message" => "Berhasil", "order_id" => $order_id]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>