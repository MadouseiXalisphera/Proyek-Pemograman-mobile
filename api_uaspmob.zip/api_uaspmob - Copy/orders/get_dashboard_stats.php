<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

require_once "../config/connect.php";

try {
    // Ambil total penjualan per hari selama seminggu terakhir
    $sql = "
        SELECT WEEKDAY(created_at) as day_index, SUM(total_price) as daily_revenue
        FROM orders
        WHERE payment_confirmed = 1 AND cancelled = 0
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY day_index
    ";
    
    $result = $conn->query($sql);
    
    // Siapkan array kosong untuk Senin (0) sampai Minggu (6)
    $sales = [0, 0, 0, 0, 0, 0, 0];
    $max_sales = 0;

    if ($result) {
        while($row = $result->fetch_assoc()) {
            $idx = (int)$row['day_index'];
            $revenue = (double)$row['daily_revenue'];
            
            $sales[$idx] = $revenue;
            
            // Cari nilai penjualan tertinggi untuk batas atas grafik (maxY)
            if ($revenue > $max_sales) {
                $max_sales = $revenue;
            }
        }
    }
    
    echo json_encode([
        "success" => true, 
        "data" => $sales,
        "max_sales" => $max_sales
    ]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>