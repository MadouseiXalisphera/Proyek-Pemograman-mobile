<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/connect.php";

$orderId = $_GET['order_id'];

$stmt = $conn->prepare("
SELECT *
FROM order_items
WHERE order_id = ?
");

$stmt->bind_param("i", $orderId);
$stmt->execute();

$result = $stmt->get_result();

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);