<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/connect.php";

try {
    $sql = "SELECT oi.id AS item_id, oi.order_id, o.table_name, o.customer_name, oi.menu_name, oi.quantity, oi.status 
            FROM order_items oi 
            JOIN orders o ON oi.order_id = o.id 
            WHERE oi.status = 'done' AND o.cancelled = 0
            ORDER BY o.created_at DESC";
    $result = $conn->query($sql);
    $data = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    echo json_encode(["success" => true, "data" => $data]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>