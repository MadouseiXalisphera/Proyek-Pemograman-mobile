<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

require_once "../config/connect.php";

// Ambil ID dari POST
$id = isset($_POST['id']) ? $_POST['id'] : '';

if(empty($id)) {
    echo json_encode(["success" => false, "message" => "ID Order kosong"]);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE orders SET payment_confirmed = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $success = $stmt->execute();

    if ($success) {
        echo json_encode(["success" => true, "message" => "Berhasil dikonfirmasi"]);
    } else {
        echo json_encode(["success" => false, "message" => "Gagal eksekusi: " . $stmt->error]);
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>