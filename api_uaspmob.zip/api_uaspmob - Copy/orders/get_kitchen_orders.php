<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/connect.php";

// ... kode atas tetap sama ...
$sql = "SELECT oi.id AS item_id, oi.order_id, o.table_name, o.customer_name, oi.menu_name, oi.quantity, oi.status 
        FROM order_items oi 
        JOIN orders o ON oi.order_id = o.id 
        WHERE o.payment_confirmed = 1 AND o.cancelled = 0 AND oi.status != 'done'
        ORDER BY o.created_at ASC";
// ... kode bawah tetap sama ...

$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);