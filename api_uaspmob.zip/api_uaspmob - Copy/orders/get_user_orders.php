<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

require_once "../config/connect.php";

$table_name = $_GET['table_name'] ?? '';

if ($table_name == '') {
    echo json_encode([
        "success" => false,
        "message" => "table_name wajib"
    ]);
    exit;
}

// Tambahkan o.cancelled dan o.payment_confirmed
$sql = "
SELECT
    oi.id AS item_id,
    oi.order_id,
    o.table_name,
    oi.menu_name,
    oi.quantity,
    oi.price,
    oi.status,
    o.created_at,
    o.cancelled,
    o.payment_confirmed
FROM order_items oi
JOIN orders o ON oi.order_id = o.id
WHERE o.table_name = ? AND o.is_hidden = 0
ORDER BY o.created_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $table_name);
$stmt->execute();

$result = $stmt->get_result();
$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);
?>