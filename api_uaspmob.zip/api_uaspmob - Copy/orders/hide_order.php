<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

require_once "../config/connect.php";

$order_id = isset($_POST['order_id']) ? $_POST['order_id'] : '';

if(empty($order_id)) {
    echo json_encode(["success" => false, "message" => "ID Order kosong"]);
    exit;
}

try {
    // Update is_hidden menjadi 1
    $stmt = $conn->prepare("UPDATE orders SET is_hidden = 1 WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $success = $stmt->execute();

    echo json_encode(["success" => $success]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>