<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // Matikan display error agar tidak merusak format JSON

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

require_once "../config/connect.php";

$data = [];
try {
    $sql = "SELECT * FROM orders WHERE payment_confirmed = 0 AND cancelled = 0 ORDER BY created_at DESC";
    $result = $conn->query($sql);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode(["success" => true, "data" => $data]);
    } else {
        echo json_encode(["success" => false, "message" => "Query Failed: " . $conn->error]);
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>