<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/connect.php";

$id = $_POST['id'] ?? '';
$status = $_POST['status'] ?? '';

if ($id == '' || $status == '') {
    echo json_encode([
        "success" => false,
        "error" => "Parameter tidak lengkap"
    ]);
    exit;
}

$stmt = $conn->prepare("
UPDATE order_items
SET status = ?
WHERE id = ?
");

$stmt->bind_param(
    "si",
    $status,
    $id
);

$ok = $stmt->execute();

echo json_encode([
    "success" => $ok
]);